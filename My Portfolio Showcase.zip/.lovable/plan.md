Portfolio for Bala Shiva Teja Kandimalla

Build a modern, premium, recruiter-friendly single-page portfolio for Bala Shiva Teja Kandimalla at /, positioning him as a highly experienced Senior UX/UI Designer with 12+ years of experience across fintech, healthcare, retail, aerospace, and enterprise product design.

The portfolio should feel world-class, editorial, and designer-grade — modern but timeless, with strong visual hierarchy, elegant typography, generous whitespace, refined interactions, and clear storytelling. The goal is to help recruiters, hiring managers, and clients quickly understand Bala’s experience, strengths, and credibility.

Primary objective

- Showcase Bala as a senior-level product and UX/UI design professional

- Emphasize depth of experience, enterprise impact, cross-functional collaboration, and product thinking

- Make the site visually memorable but highly usable

- Drive resume downloads and inbound contact

- Keep it concise, polished, and easy to scan

Tone and positioning

- Confident, mature, strategic, modern

- Less “template portfolio,” more “senior designer personal brand site”

- Copy should sound credible, concise, and outcomes-oriented

- Avoid generic filler and overly decorative UI

- Frame Bala as someone who solves complex product problems, leads design thinking, and delivers business value

Design direction

- Modern, maximum designer-grade aesthetic

- Large type, clean structure, strong spacing rhythm, subtle motion

- Light theme overall with a single refined accent color

- Use a sophisticated serif + sans pairing for a premium feel

- Dark sections used sparingly for contrast and visual rhythm

- Keep the UI minimal, elevated, and uncluttered

- Add tasteful microinteractions, smooth scrolling, hover refinement, and subtle reveal animations

- Avoid loud gradients, over-glassmorphism, or generic startup visuals

Visual style references

- Think premium portfolio meets modern product design presentation

- Elegant editorial layout, restrained color, polished components

- Strong section transitions and premium spacing

- Make it feel custom-crafted for a senior UX/UI designer

Information architecture

Use a one-page scrolling layout with anchored navigation:

- Home

- About

- Experience

- Skills

- Education

- Contact

Header / navigation

- Sticky top navigation with clean anchor links

- Include a prominent “Download Resume” CTA in the header

- Keep nav minimal and polished

- Add active section highlight on scroll if possible

Hero section

Purpose:

Immediately establish Bala’s seniority, specialty, and value.

Include:

- Name: Bala Shiva Teja Kandimalla

- Title: Senior UX/UI Designer

- Strong one-line positioning statement, for example:

  “Designing intuitive, scalable digital experiences across enterprise, product, and customer-facing platforms.”

- Short supporting paragraph emphasizing 12+ years of experience across complex domains and cross-functional teams

- CTAs:

  - Download Resume

  - Get in Touch

- Add a subtle “Currently open to senior UX/UI, product design, and contract opportunities” line

- Optionally include a compact trust strip with industries or top companies: Charles Schwab, Centene, Target, Boeing, Autodesk

About section

- Write a strong professional summary based on the resume

- Focus on Bala’s approach: user-centered design, product thinking, collaboration, end-to-end design, research-informed decisions, scalable systems

- Keep the copy concise and executive-level

- Make this section feel like a polished personal brand summary, not a generic bio

Experience section

This should be one of the strongest and most visually compelling sections.

Create a premium timeline or structured experience layout for:

- Charles Schwab

- Centene

- Target

- Boeing

- Autodesk

For each role include:

- Company name

- Role title

- Dates

- Location

- 3–5 strong bullet points

Upgrade the bullets so they sound more strategic and accomplishment-oriented, while staying truthful to the resume. Emphasize:

- Product and platform design

- UX strategy

- UI modernization

- Design systems

- User research / testing

- Stakeholder collaboration

- Cross-functional execution

- Business impact

- Enterprise-scale complexity

If possible, add a subtle visual treatment that makes each company feel distinct but consistent.

Prioritize scanability and hierarchy. Hiring managers should be able to skim this section quickly. Hiring teams value portfolios that clearly explain problems, approach, and outcomes in a scannable structure. [web:8][web:16][web:20]

Skills / competencies section

Present this as a polished, well-structured capability map rather than just random tags.

Group skills into elegant chip/card clusters:

- Design Tools

- UX Methods

- UI / Product Design

- Research & Strategy

- Design Systems

- Collaboration & Delivery

Possible examples:

- Figma

- Sketch

- Adobe XD

- Photoshop

- Illustrator

- InVision

- Wireframing

- Prototyping

- User Flows

- Information Architecture

- Interaction Design

- Visual Design

- Usability Testing

- Journey Mapping

- Design Systems

- Responsive Design

- Accessibility

- Stakeholder Workshops

- Agile Collaboration

- Developer Handoff

Make this section visually attractive and highly organized.

Show breadth, but keep it intentional and senior-level.

Education section

Include:

- University of Southern Mississippi — MS

- Parul University — BS

Keep this section elegant and minimal.

Contact section

Make it easy for recruiters and clients to reach Bala.

Include:

- Email

- Phone

- LinkedIn

- Short closing statement inviting opportunities

Suggested tone:

“Open to senior UX/UI design, product design, and consulting opportunities. Available for conversations with recruiters, hiring teams, and clients.”

Add a final CTA block before the footer encouraging resume download or direct contact.

Footer

- Bala Shiva Teja Kandimalla

- Senior UX/UI Designer

- LinkedIn

- Email

- Small copyright line

Resume download

- Upload the PDF to Lovable Assets CDN via lovable-assets create

- The “Download Resume” button must use:

  <a href={resumeAsset.url} download>

- Include the Download Resume CTA in:

  - Header

  - Hero

  - Final CTA section

Technical requirements

- Replace src/routes/index.tsx placeholder with the portfolio page

- Update __root.tsx head:

  - title: “Bala Shiva Teja Kandimalla — Senior UX/UI Designer”

  - meta description focused on senior UX/UI design experience and portfolio

  - Open Graph tags for sharing

- Create reusable components in src/components/portfolio/:

  - Hero

  - About

  - Experience

  - Skills

  - Education

  - Contact

- Use existing shadcn Button, Badge, Card

- Add smooth scroll for one-page anchor navigation

- No backend, auth, or database

Styling requirements

- Use Tailwind v4 tokens in src/styles.css

- Add a refined accent color and font tokens

- Load Inter for body text and a refined display serif in root head

- Use a premium neutral palette with one elegant accent

- Use dark sections only for emphasis, such as the experience highlight or CTA band

- Add subtle section transitions, hover polish, and motion that feels premium and restrained

Content guidance

- Make all copy concise, strategic, and recruiter-friendly

- Avoid generic phrases like “passionate designer”

- Focus on clarity, seniority, decision-making, collaboration, and impact

- Keep the content skimmable with excellent hierarchy

- Emphasize Bala’s years of experience and recognizable companies

- The portfolio should feel optimized for both recruiter review and client trust

Optional enhancements

- Add a small “Selected Experience” intro before the timeline

- Add company logos if available and tasteful

- Add a compact “Core Strengths” strip near the hero

- Add subtle metrics or outcomes if present in the resume

- Add a “Let’s work together” CTA band near the bottom

Overall quality bar

This should not feel like a basic personal portfolio template.

It should feel like a sophisticated, modern UX designer portfolio that reflects seniority, clarity, taste, and product thinking.

Prioritize excellent typography, visual hierarchy, whitespace, and storytelling. A strong portfolio should include a clear introduction, contact information, and a small number of relevant case-study-style experience highlights that are easy to navigate. [web:21][web:22]