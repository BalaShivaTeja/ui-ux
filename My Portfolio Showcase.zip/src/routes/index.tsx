import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Download, Mail, Phone, Linkedin, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import resumeAsset from "@/assets/resume.pdf.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bala Shiva Teja Kandimalla — Senior UX/UI Designer" },
      {
        name: "description",
        content:
          "Portfolio of Bala Shiva Teja Kandimalla — Senior UX/UI Designer with 12+ years of experience designing accessible, user-centered products across fintech, healthcare, retail, and aerospace.",
      },
      { property: "og:title", content: "Bala Shiva Teja Kandimalla — Senior UX/UI Designer" },
      {
        property: "og:description",
        content:
          "12+ years designing accessible, scalable, user-centered digital experiences across enterprise and consumer products.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Portfolio,
});

const experience = [
  {
    company: "Charles Schwab",
    role: "Senior UX/UI Designer",
    dates: "Feb 2024 — Present",
    location: "Westlake, TX",
    bullets: [
      "Lead end-to-end UX for data-intensive financial services applications — information architecture, user flows, and high-fidelity visual design aligned with enterprise standards.",
      "Run structured user research (interviews, contextual inquiry, behavioral analytics) to inform decisions and validate interaction patterns.",
      "Apply WCAG 2.1 and ADA standards through usability testing and accessibility audits to ensure inclusive experiences.",
      "Ship Figma prototypes, interactive wireframes, and reusable component libraries with pixel-precise developer handoff.",
      "Partner with product owners and engineering to preserve design integrity across the full product lifecycle.",
    ],
  },
  {
    company: "Centene Corporation",
    role: "Senior UX/UI Designer",
    dates: "Aug 2022 — Jan 2024",
    location: "Saint Louis, MO",
    bullets: [
      "Transformed complex healthcare data and system workflows into accessible, visually clear interfaces through multi-step research and usability testing.",
      "Designed HIPAA-aware responsive layouts in Figma with consistent cross-platform behavior across web and mobile.",
      "Built and maintained UI component libraries and visual design systems for scalability and brand alignment.",
      "Facilitated usability sessions and synthesized findings into actionable recommendations for product and business stakeholders.",
    ],
  },
  {
    company: "Target",
    role: "Product Designer — Ecommerce & Analytics",
    dates: "May 2019 — Jul 2022",
    location: "Minneapolis, MN",
    bullets: [
      "Led UX redesigns for high-traffic ecommerce and analytics platforms, grounded in behavioral data and usability findings.",
      "Designed information-rich dashboards and reporting components with comprehensive Figma component libraries.",
      "Ensured WCAG 2.1 AA conformance across contrast, keyboard navigation, and screen reader compatibility.",
      "Delivered compelling design rationale during sprint planning and stakeholder reviews to align teams on user-centered decisions.",
    ],
  },
  {
    company: "Boeing",
    role: "Senior UX/UI Designer",
    dates: "Dec 2016 — Apr 2019",
    location: "Arlington, VA",
    bullets: [
      "Designed responsive, interactive layouts for data-heavy enterprise applications using mobile-first, accessible patterns.",
      "Translated complex business and technical requirements into modular, task-oriented user pathways.",
      "Built reusable interface components and email templates to preserve brand alignment across modules.",
    ],
  },
  {
    company: "Autodesk",
    role: "UX/UI Designer",
    dates: "Jan 2013 — Nov 2016",
    location: "San Francisco, CA",
    bullets: [
      "Partnered with research teams on extensive usability testing, mapping iterative design improvements from real user feedback.",
      "Designed fluid SPA interfaces, navigation structures, and multi-step form patterns to streamline complex interactions.",
      "Maintained pixel-perfect delivery across browsers and collaborated with QA on compliance and design review.",
    ],
  },
];

const skillGroups = [
  {
    title: "Design Tools",
    items: ["Figma", "Adobe Suite", "Dreamweaver", "Material-UI", "Bootstrap", "SASS / LESS"],
  },
  {
    title: "UX Methods",
    items: [
      "User Research",
      "Usability Testing",
      "Journey Mapping",
      "Wireframing",
      "Prototyping",
      "Heuristic Evaluation",
    ],
  },
  {
    title: "Design Specialties",
    items: [
      "Interaction Design",
      "Information Architecture",
      "Visual Design",
      "Responsive Design",
      "Design Systems",
      "Component Libraries",
    ],
  },
  {
    title: "Accessibility",
    items: ["WCAG 2.1 AA/AAA", "ADA Compliance", "Inclusive Design", "Accessibility Audits"],
  },
  {
    title: "Collaboration",
    items: ["Agile / Scrum", "Stakeholder Workshops", "Developer Handoff", "Design Rationale"],
  },
];

function Portfolio() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <About />
      <Experience />
      <Skills />
      <Education />
      <Contact />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="#top" className="font-display text-lg font-semibold tracking-tight">
          Bala<span className="text-accent">.</span>
        </a>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#about" className="transition-colors hover:text-foreground">About</a>
          <a href="#experience" className="transition-colors hover:text-foreground">Experience</a>
          <a href="#skills" className="transition-colors hover:text-foreground">Skills</a>
          <a href="#contact" className="transition-colors hover:text-foreground">Contact</a>
        </nav>
        <Button asChild size="sm" className="rounded-full">
          <a href={resumeAsset.url} download>
            <Download className="mr-2 h-4 w-4" />
            Resume
          </a>
        </Button>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[600px] w-[1200px] -translate-x-1/2 rounded-full bg-accent/10 blur-3xl" />
      </div>
      <div className="mx-auto max-w-6xl px-6 pb-24 pt-20 md:pt-32">
        <Badge variant="secondary" className="mb-6 rounded-full px-3 py-1 text-xs font-medium">
          <span className="mr-2 inline-block h-2 w-2 rounded-full bg-emerald-500" />
          Open to senior UX/UI &amp; product design opportunities
        </Badge>
        <h1 className="font-display text-5xl font-medium leading-[1.05] tracking-tight md:text-7xl">
          Bala Shiva Teja
          <br />
          <span className="text-muted-foreground">Kandimalla</span>
        </h1>
        <p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground md:text-xl">
          Senior UX/UI Designer with{" "}
          <span className="text-foreground">12+ years</span> of experience designing intuitive,
          accessible, and scalable digital experiences across fintech, healthcare, retail, and
          aerospace.
        </p>
        <div className="mt-10 flex flex-wrap items-center gap-4">
          <Button asChild size="lg" className="rounded-full">
            <a href={resumeAsset.url} download>
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </a>
          </Button>
          <Button asChild size="lg" variant="outline" className="rounded-full">
            <a href="#contact">
              Get in touch
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
        <div className="mt-16 flex flex-wrap items-center gap-x-10 gap-y-4 border-t border-border pt-8 text-sm uppercase tracking-widest text-muted-foreground">
          <span>Charles Schwab</span>
          <span>Centene</span>
          <span>Target</span>
          <span>Boeing</span>
          <span>Autodesk</span>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="border-t border-border bg-muted/30">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-12 md:grid-cols-[1fr_2fr]">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">About</p>
            <h2 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">
              Designing for clarity at enterprise scale.
            </h2>
          </div>
          <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
            <p>
              I lead end-to-end product design — from discovery through delivery — with deep
              expertise in user research, usability testing, information architecture, and visual
              design. My work focuses on translating complex workflows into intuitive, pixel-perfect
              experiences.
            </p>
            <p>
              Across government, enterprise, and public-sector contexts, I partner with
              cross-functional teams to deliver accessible, human-centered solutions aligned with
              WCAG 2.1 and ADA standards.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="border-t border-border">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="mb-16 flex items-end justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Experience</p>
            <h2 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">
              Selected roles
            </h2>
          </div>
          <p className="hidden text-sm text-muted-foreground md:block">12+ years · 5 companies</p>
        </div>
        <div className="space-y-16">
          {experience.map((job) => (
            <article
              key={job.company}
              className="group grid gap-6 border-t border-border pt-10 md:grid-cols-[1fr_2fr]"
            >
              <div>
                <h3 className="font-display text-2xl font-medium tracking-tight">
                  {job.company}
                </h3>
                <p className="mt-2 text-foreground">{job.role}</p>
                <p className="mt-1 text-sm text-muted-foreground">{job.dates}</p>
                <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  {job.location}
                </p>
              </div>
              <ul className="space-y-3 text-muted-foreground">
                {job.bullets.map((b, i) => (
                  <li key={i} className="flex gap-3 leading-relaxed">
                    <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" className="border-t border-border bg-muted/30">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="mb-16">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">Capabilities</p>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">
            Skills &amp; tools
          </h2>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {skillGroups.map((group) => (
            <div
              key={group.title}
              className="rounded-2xl border border-border bg-background p-6"
            >
              <h3 className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                {group.title}
              </h3>
              <div className="mt-4 flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <Badge key={item} variant="secondary" className="rounded-full font-normal">
                    {item}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Education() {
  return (
    <section className="border-t border-border">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="mb-16">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">Education</p>
          <h2 className="mt-2 font-display text-3xl font-medium tracking-tight md:text-4xl">
            Academic background
          </h2>
        </div>
        <div className="grid gap-8 md:grid-cols-2">
          <div className="rounded-2xl border border-border p-8">
            <p className="text-sm text-muted-foreground">Dec 2013</p>
            <h3 className="mt-2 font-display text-xl font-medium">
              The University of Southern Mississippi
            </h3>
            <p className="mt-2 text-muted-foreground">
              M.S. in Computer and Information Sciences
            </p>
          </div>
          <div className="rounded-2xl border border-border p-8">
            <p className="text-sm text-muted-foreground">May 2012</p>
            <h3 className="mt-2 font-display text-xl font-medium">Parul University</h3>
            <p className="mt-2 text-muted-foreground">B.S. in Computer Science</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="border-t border-border bg-foreground text-background">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid gap-12 md:grid-cols-[2fr_1fr]">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">Contact</p>
            <h2 className="mt-2 font-display text-4xl font-medium tracking-tight md:text-5xl">
              Let&apos;s build something thoughtful together.
            </h2>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-background/70">
              Available for senior UX/UI, product design, and consulting opportunities. I&apos;d
              love to hear from recruiters, hiring teams, and clients.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Button asChild size="lg" variant="secondary" className="rounded-full">
                <a href={resumeAsset.url} download>
                  <Download className="mr-2 h-4 w-4" />
                  Download Resume
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="rounded-full border-background/30 bg-transparent text-background hover:bg-background hover:text-foreground"
              >
                <a href="mailto:balashivakandimalla@gmail.com">
                  <Mail className="mr-2 h-4 w-4" />
                  Send email
                </a>
              </Button>
            </div>
          </div>
          <div className="space-y-5 text-background/80">
            <a
              href="mailto:balashivakandimalla@gmail.com"
              className="flex items-center gap-3 transition-colors hover:text-background"
            >
              <Mail className="h-4 w-4 text-accent" />
              balashivakandimalla@gmail.com
            </a>
            <a
              href="tel:+18172136864"
              className="flex items-center gap-3 transition-colors hover:text-background"
            >
              <Phone className="h-4 w-4 text-accent" />
              +1 (817) 213-6864
            </a>
            <a
              href="https://linkedin.com/in/teja-kandimalla"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 transition-colors hover:text-background"
            >
              <Linkedin className="h-4 w-4 text-accent" />
              linkedin.com/in/teja-kandimalla
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-6 py-8 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
        <p>© {new Date().getFullYear()} Bala Shiva Teja Kandimalla</p>
        <p>Senior UX/UI Designer</p>
      </div>
    </footer>
  );
}
